import { LoadingController, AlertController, ToastController, App, Events } from 'ionic-angular';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
let hastoken, self;
@Injectable()

export class AppGlobal {

    static cache: any = {
        slides: "_dress_slides",
        categories: "_dress_categories",
        products: "_dress_products"
    }

    static domain = "";
    static imgsrc = "";//文章列表
    static shopsrc = "";//活动，商品
    static iosAppId = ''// 1332971579 ios APPid
    static API: any = {
        getCategories: '/api/ionic3/getCategories',
        getProducts: '/api/ionic3/getProducts',
        getDetails: '/api/ionic3/details',
    };

}

@Injectable()
export class AppService {
    public user_token: string = ''; hasemore = true;;
    public headers; public doinit: any; public doRefresh; public doMoreload;
    constructor(public http: Http, public events: Events, public loadingCtrl: LoadingController, private alertCtrl: AlertController, private toastCtrl: ToastController, public app: App) {
        self = this;
    }
    encode(params) {
        var str = '';
        if (params) {
            for (var key in params) {
                if (params.hasOwnProperty(key)) {
                    var value = params[key];
                    str += encodeURIComponent(key) + '=' + encodeURIComponent(value) + '&';
                }
            }
            str = '?' + str.substring(0, str.length - 1);
        }
        return str;
    }
    httpGet(url, params, callback, loader: boolean = true, token?) {
        this.getItem("user_token", res => {
            hastoken = res
        })
        console.log("get请求")
        if (this.checktokens()) {
            this.headers = {
                headers: {
                    'Token': token || hastoken
                }
            };
            let loading = this.loadingCtrl.create({
                content: '加载中...'//数据加载中显示
            });
            if (loader) {
                loading.present();
            }
            this.http.get(AppGlobal.domain + url + this.encode(params), this.headers)
                .toPromise()
                .then(res => {
                    var d;
                    console.log(res.json())
                    if (res.json().IsValid) {
                        d = res.json().Data
                        if (res.json().Data == '') {
                            d = true;
                        }
                    }
                    if (loader) {
                        loading.dismiss();
                    }
                    callback(d == null ? "[]" : d);
                })
                .catch(error => {
                    console.log(error)
                    console.log(error.status)

                    if (loader) {
                        loading.dismiss();
                    }
                    this.handleError(error);
                });
        } else {
            var d = false
            callback(d);
            console.log("清除数据")
            this.setItem("userInfo", "");
            this.setItem("user_token", "");
            this.setItem("oldtime", "");
            this.events.publish('toLogin');

        }
    }
    httpPost(url, params, callback, loader: boolean = false, token?) {
        this.getItem("user_token", res => {
            hastoken = res
        })
        console.log(hastoken)
        console.log("post请求")
        if (this.checktokens()) {

            if (url == '/Api/MediaFiles/Upload') {
                console.log("图片上传");
                this.headers = {
                    headers: {
                        'Accept': 'application/json',
                        'Token': token || hastoken,
                        'Content-Type': 'multipart/form-data'
                    }
                };
                console.log(this.headers)
            } else {
                this.headers = {
                    headers: {
                        'Token': token || hastoken,

                    }
                };
            }
            console.log(params)
            let loading = this.loadingCtrl.create({
                content: '加载中...'//数据加载中显示
            });
            if (loader) {
                loading.present();
            }
            this.http.post(AppGlobal.domain + url, params, this.headers)
                .toPromise()
                .then(res => {
                    var d;
                    console.log(res.json())
                    if (res.json().IsValid) {
                        d = res.json().Data;
                        if (res.json().Data == '') {
                            d = true;
                        }
                    } else {
                        d = res.json().ErrorMessages
                    }

                    if (loader) {
                        loading.dismiss();
                    }
                    callback(d == null ? "[]" : d);
                }).catch(error => {
                    console.log(error)
                    if (error.status == 401) {
                        self.events.publish('toLogin');
                        callback(error.status);

                    }
                    console.log(loader)
                    if (loader) {
                        console.log(loader)
                        loading.dismiss();
                    }
                    this.handleError(error);
                });
        } else {
            var d = false
            callback(d);
            this.setItem("userInfo", "");
            this.setItem("user_token", "");
            this.setItem("oldtime", "");
            console.log("清除数据")
            this.events.publish('toLogin');

        }
    }


    post(){
        this.http
    }
    private handleError(error: Response | any) {
        let msg = '';
        console.log(error)
        this.toast(error.ErrorMessages);
        if (error.status == 400) {
            msg = '请求无效(code：404)';
            console.log('请检查参数类型是否匹配');
        }
        if (error.status == 401) {
            msg = 'token失效)';
            console.log('token失效,返回登陆')
            this.events.publish('toLogin');
        }
        if (error.status == 404) {
            msg = '请求资源不存在(code：404)';
            console.error(msg + '，请检查路径是否正确');
        }
        if (error.status == 500) {
            msg = '服务器发生错误(code：500)';
            console.error(msg + '，请检查路径是否正确');
        }
        console.log(error);
        if (msg != '') {
            this.toast(msg);
        }
    }

    alert(message, callback?) {
        if (callback) {
            let alert = this.alertCtrl.create({
                title: '提示',
                message: message,
                buttons: [{
                    text: "确定",
                    handler: data => {
                        callback();
                    }
                }]
            });
            alert.present();
        } else {
            let alert = this.alertCtrl.create({
                title: '提示',
                message: message,
                buttons: ["确定"]
            });
            alert.present();
        }
    }
    toast(message, callback?) {
        let toast = this.toastCtrl.create({
            message: message,
            duration: 2000,
            dismissOnPageChange: true,
        });
        toast.present();
        if (callback) {
            callback();
        }
    }

    checktokens() {
        let a, b;
        this.getItem("oldtime", res => {
            a = res;
        })
        if (!hastoken) {
            console.log("是登陆")
            return true
        } else {
            this.getItem("user_token", res => {
                b = res;
            })
            return this.checktoken(b, a)
        }
    }
    checktoken(token, oldtime) {
        if (typeof (token) == "undefined" || token == "") {
            return false;
        }
        var nowtime = new Date().getTime()
        //判断当前时间和过期时间的比较
        if (nowtime < oldtime) {
            return true;
        } else {
            return false;
        }
    }
    //时间戳格式化
    getNowFormatDate(date, hashour) {
        // return new Date(parseInt(date)*1000).toLocaleString().replace(/:d{1,2}$/,'')
        //return new Date(parseInt(date)*1000).toLocaleString().replace(/年|月/g,"-").replace(/日/g,' ')
        var now = new Date(date);
        var year = now.getFullYear();
        var month = now.getMonth() + 1;
        var date: any = now.getDate();
        var hour: any = now.getHours();
        if (hour < 10) { hour = "0" + hour }
        var minute: any = now.getMinutes();
        if (minute < 10) { minute = "0" + minute }
        var second: any = now.getSeconds();
        if (second < 10) { second = "0" + second }
        console.log(year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second)
        if (hashour) {
            return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
        } else {
            return year + "-" + month + "-" + date;
        }
    }

    setItem(key: string, obj: any) {
        try {
            var json = JSON.stringify(obj);
            window.localStorage[key] = json;
        }
        catch (e) {
            console.error("window.localStorage error:" + e);
        }
    }
    getItem(key: string, callback) {
        try {
            var json = window.localStorage[key];
            var obj = JSON.parse(json);
            callback(obj);
        }
        catch (e) {
            console.error("window.localStorage error:" + e);
        }
    }
    //页面处理
    pageAsk(askPageType, par, call) {
        if (askPageType == 1 || askPageType == 2) {
            console.log('页面初始化或者刷新')
            par.PageIndex = 1;
            call(par)
        } else if (askPageType == 3) {
            console.log("页面加载更多")
            par.PageIndex = par.PageIndex + 1;
            call(par)
        }
        console.log('返回的par', par)
    }
    //分页初始化
    chushihua(askUrl: string, params, callback, askPageType, refreshType?) {
        console.log(askUrl, params, askPageType, refreshType)
        this.pageAsk(askPageType, params, res => {
            params.PageIndex = res.PageIndex
            this.httpPost(askUrl, params, d => {
                if (d) {
                    callback(d)
                    if (refreshType) {
                        refreshType.complete();
                    }
                } else {
                    if (refreshType) {
                        refreshType.complete();
                        this.toast("请求超时，请稍后再试")
                    }
                }
            });
        })
    }
    // 倒计时
    countDown(){
        

    }
}
